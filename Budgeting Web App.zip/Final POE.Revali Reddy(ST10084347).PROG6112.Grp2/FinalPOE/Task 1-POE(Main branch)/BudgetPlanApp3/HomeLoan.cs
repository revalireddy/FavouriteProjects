﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BudgetPlanApp3
{
    //HomeLoan - child class  , is derived from the expenses - parent class
    class HomeLoan : Expenses
    {
        //variables for homeloan calculation
        private double price;
        private double deposit;
        private double interestRate;
        private double repayMonths;
        public double  repayment;

        //method overriden from the expenses class
        override public double monthlyRepayments()
        {
            //variables for calculation
            double principleAmount;
            double years;
            double Amount;

            Console.Write("Enter the purchase price of the property                 : R ");
            price = Convert.ToDouble(Console.ReadLine());

           
            Console.Write("Enter the total deposit amount                           : R ");
            deposit = Convert.ToDouble(Console.ReadLine());

            
            Console.Write("Enter the Interest rate (percentage)                     :   ");
            interestRate = Convert.ToDouble(Console.ReadLine());

           
            Console.Write("Enter the number of months to repay (Choose 240 OR 360)  : R ");
            repayMonths = Convert.ToDouble(Console.ReadLine());

            //calculates monhtly repayment for homeloan
            principleAmount = price - deposit; 
            interestRate = interestRate / 100; 
            years = repayMonths / 12; 
            Amount = principleAmount * (1 * (interestRate * years)); 

            repayment = Amount / repayMonths;
            repayment = Math.Round(repayment, 2); 

            //displays the monthly repayment amount
            Console.Write("Your monthly home loan repayment is                     : R " + Math.Round((Double)repayment, 2) + "\n");
           
            return repayment;




        }
        //method checks if the user is eligible for the home loan or not but comparing it to a portion of users gross income
        public void loanAcceptance(double grossIncome)
        {
            if ((grossIncome / 3) < repayment)
            {
                Console.BackgroundColor = ConsoleColor.DarkYellow;
                Console.ForegroundColor = ConsoleColor.Black;
                Console.WriteLine("\nALERT : Home loan approval is unlikely\n");
                Console.BackgroundColor = ConsoleColor.Black;
                Console.ForegroundColor = ConsoleColor.White;
            }
            else
            {
                Console.BackgroundColor = ConsoleColor.Green;
                Console.ForegroundColor = ConsoleColor.White;
                Console.WriteLine("Home loan approval is likely !\n");
                Console.BackgroundColor = ConsoleColor.Black;
                Console.ForegroundColor = ConsoleColor.White;

            }
        }

    }
}

