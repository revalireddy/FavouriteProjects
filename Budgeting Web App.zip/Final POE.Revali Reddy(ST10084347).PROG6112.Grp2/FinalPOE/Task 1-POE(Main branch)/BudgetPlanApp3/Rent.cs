﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BudgetPlanApp3
{
    //HomeLoan - child class  , is derived from the expenses - parent cla
    class Rent : Expenses
    {
        //variable to store rent entered by the user
        public double rentAmount;

        

        public Rent()
        {

        }

       
        //method retrieves monthly rent from user - overrides the monthlyRepayments method in expenses class
        override public double monthlyRepayments()
        {
            Console.Write("Enter the montly rent amount                     : R ");
            rentAmount = Convert.ToDouble(Console.ReadLine());
            return rentAmount;
        }
    }
}
