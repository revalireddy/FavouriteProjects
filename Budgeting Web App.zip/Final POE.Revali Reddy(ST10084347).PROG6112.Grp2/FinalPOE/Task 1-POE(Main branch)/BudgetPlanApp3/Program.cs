﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace BudgetPlanApp3
{
    public class Program
    {

        //variable for income
        private static double grossIncome; 

        //variables for general expenses
        private static double estimatedMonthlyTax;
        private static double accomodationExpenses;
        private static double allExpenses;
        

        
        private static double groceries;
        private static double waterLights;
        private static double travelCosts;
        private static double phone;
        private static double otherExpenses;


        //arraylist to store expenses
        private static List<double> expenses = new List<double>();
        static void Main(string[] args)
        {
          
            /*                    -- introduction --
             * splashscreen
             * uses thread to count
             * houseKeeping
             */
            Console.BackgroundColor = ConsoleColor.Black;
            Console.ForegroundColor = ConsoleColor.Red;
            string s = "****************** BUDGET PLAN APP *****************\n\n";

           //Dayan[online](20 February 2014)|How do I center text in a console application? [duplicate]|Available:https://stackoverflow.com/questions/21917203/how-do-i-center-text-in-a-console-application
            Console.SetCursorPosition((Console.WindowWidth - s.Length) / 2, Console.CursorTop);
            Console.WriteLine(s);

            Console.WriteLine("Loading...");

            for (int i = 5; i > 0; i--)
            {
            //Anonymous[online](24 January 2019)|How to create Threads in C#|Available :https://www.geeksforgeeks.org/how-to-create-threads-in-c-sharp/
                Console.Write(i + "  ");
                Thread.Sleep(1000);

            }
           
            Console.BackgroundColor = ConsoleColor.Black;
            Console.ForegroundColor = ConsoleColor.Green;


            Console.WriteLine("\n");

            //pulls methods into main method to execute
            expensesInput();

            
            GeneralexpensesInput();

            
            AccomadationOptions();


            

            Console.ReadKey();

           


        }
        //method to retrieve user input about income and their tax
        static void expensesInput()
        {
            
            Console.Write("************************************\n\n");
            Console.Write("Enter your gross monthly income : R ");
            grossIncome = Convert.ToDouble(Console.ReadLine());

           
            Console.Write("Enter your estimated monthly tax: R ");
            estimatedMonthlyTax = Convert.ToDouble(Console.ReadLine());
            expenses.Add(estimatedMonthlyTax);
            Console.WriteLine("**********************************\n\n");
        }
        //method to retrieve user input  about general expenses
        static void GeneralexpensesInput()
        {
            Console.Write("Enter the estimated monthly cost for:\n");

            //Anonymous[online]|Java ArrayList |Available+:https://www.w3schools.com/java/java_arraylist.asp
            Console.Write("Groceries                      : R ");
            groceries = Convert.ToInt32(Console.ReadLine());
            expenses.Add(groceries);

           
            Console.Write("Water and lights               : R ");
            waterLights = Convert.ToInt32(Console.ReadLine());
            expenses.Add(waterLights);

           
            Console.Write("Travel costs(including petrol) : R ");
            travelCosts = Convert.ToInt32(Console.ReadLine());
            expenses.Add(travelCosts);

            
            Console.Write("Cell phone and telephone       : R ");
            phone = Convert.ToInt32(Console.ReadLine());
            expenses.Add(phone);

            
            Console.Write("Other expenses                 : R ");
            otherExpenses = Convert.ToInt32(Console.ReadLine());
            expenses.Add(otherExpenses);

            Console.WriteLine("**********************************\n\n");
        }
        //method to allow user to choose between renting and buying a house
        static void AccomadationOptions()
        {
            //create objects to pull the 2 child classes into the main method
            Rent r = new Rent();
            HomeLoan hl = new HomeLoan();

            //display - provide the user with the ability to choose between the 2 options
            Console.WriteLine("Accomdation:");
            Console.WriteLine("Will you be renting accomadation or buying a property?");
            Console.WriteLine("Enter '1' for renting ");
            Console.WriteLine("or ");
            Console.WriteLine("'2' for buying ");
            int option = Convert.ToInt32(Console.ReadLine());

            Console.BackgroundColor = ConsoleColor.Black;
            Console.ForegroundColor = ConsoleColor.Blue;



            if (option == 1)
            {
                Console.BackgroundColor = ConsoleColor.Black;
                Console.ForegroundColor = ConsoleColor.Magenta;

                rentalMethod();

            }
            else if (option == 2)
            {
                Console.BackgroundColor = ConsoleColor.Black;
                Console.ForegroundColor = ConsoleColor.Blue;

                housingMethod();

            }
            else
            {
                Console.BackgroundColor = ConsoleColor.Red;
                Console.ForegroundColor = ConsoleColor.Black;
                Console.WriteLine("Invalid selection - please try again.");
            }
        }
        //method to pull methods regarding entered values from the user
        static void rentalMethod()
        {
            
            Rent collect = new Rent();

          
            collect.setExpenses(expenses);



           
            allExpenses = collect.getallExpenses();

            //the following calculation will provide the user with an amount of how much money is left over
            accomodationExpenses = collect.monthlyRepayments();
            double availableMoney =grossIncome - (expenses.Sum() + collect.rentAmount);
            Console.WriteLine("Your available monthly money balance: R " + Math.Round((Double)availableMoney, 2));

        }
        //method to pull methods regarding entered values from the user
        static void housingMethod()
        {
            
            HomeLoan collect = new HomeLoan();

           
            collect.setExpenses(expenses);

           
            allExpenses = collect.getallExpenses();

          
            accomodationExpenses = collect.monthlyRepayments();

            //the following calculation will provide the user with an amount of how much money is left over
            double availableMoney =grossIncome - (expenses.Sum() + collect.repayment);
            Console.WriteLine("Your available monthly money balance: R " + Math.Round((Double)availableMoney, 2));

            //checks and shows the user if they are eligible for a loan or not
            collect.loanAcceptance(grossIncome);

        }
      



    }
}

