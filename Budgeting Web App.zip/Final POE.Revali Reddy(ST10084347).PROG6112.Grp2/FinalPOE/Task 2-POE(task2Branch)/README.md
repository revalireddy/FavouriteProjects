# Prog6211-ST10084347-Poe-Task2
Work in progress - Budget app
The Budget Plan App
Version 3.0

POE-Task2-ST10084347

Contents of this file 
*Introduction 
*A guide to installation 
*About the program 
*Usage *Requirements/Technical specifications 
*Technology used in this application 
*Description of the user interface 
*Known bugs 
*Project status
*Developer Information 
*FAQ

The Budget Plan App Version 3.0 
Description 
The Budget plan app has been created in the interest of assisting with personal budget planning. The aim of this app is to allow the user to track their expenses and make it simpler for the user to determine if they can make significant purchases like a home. A guide to installation 
*No installation is required for this program at this stage
 *This program can be executed by running the program.cs file *Program runs from the cmd 
*The project can be built by choosing to build from the build menu. The output pane will then display the output where compilation will take place.
 *To run the code, begin with debugging. A console window shall then appear, displaying the introduction of the Budget Plan app with a “loading…” output followed by the execution of the app. Visula studio is not required to run this app. 
 *open the file containing the program, go to the bin folder, and then open debug, then run the application file Usage 
 *The program displays an introduction to the application *The user is then required to enter an amount for each of the expenses required by the application, these include gross monthly income, estimated monthly tax deducted, groceries, water and lights, travel costs, cell phone and other expenses. 
 *The user shall be able to choose between renting accommodation, by entering “1” or buying a property by entering “2”.

If the user types 1 for rent accommodation, the user shall be able to enter the monthly rental amount. If the user types “2” to buy a property, the user shall be required to enter the amounts for the purchase price of the property, the total deposit amount, interest rate, number of months to repay (between 240 and 360). The software shall then calculate the monthly home loan repayment for buying a property based on the amounts entered by the user. If the monthly home loan payments exceed one-third of the user's gross monthly income, the program should notify the user that loan approval is improbable or not. 
*After all of the stated deductions have been made, the program should determine the available monthly money. 
*The user is then allowed to select whether to purchase a car. If the user decides to purchase a car, the user must input data such as the make and model of the vehicle, the purchasing price, deposit, interest, and monthly insurance premium which concern the vehicle they will be purchasing. 
*The program must compute the entire monthly cost of purchasing the vehicle by adding insurance and loan repayment. 
*When the user's total spending surpasses 75% of their income, the program should warn them. Display the user's expenses in descending order by value About of the program 
*This program is coded using multiple classes which use inheritance. These include the rent, HomeLoan and the car class which are the child classes, the expenses class which is the parent class and the main the class to control the whole program.
 *The expense class (parent class) consists of methods that are used to get input from the user either regarding the homeLoan or rent and car. 
 *Child classes homeLoan, rent and car consists of the methods that will calculate the monthly loan repayment from the values entered by the user. 
 *The main class consists of a method to get user input about general expenses, and a loanAcceptance method to determine if the user can qualify for the loan.
  *The main class also consists of a method that will calculate the final available amount of money. 
  *The main class includes a method to display all the expenses entered by the user in descending order with a use of a loop. 
  *The car child class uses a parameterized constructor to enable the ability to set distinct values for each instance of the class. 
  *An if-else statement has been used to enable the ability to choose between option 1 and 2 when choosing to buy a car or house or rent.
   *A delegate to notify the user when expenses exceed 75% of their income. 
   *A generic collection to store the expenses

Requirements/Technical specifications 
*This program is built to run on Windows and is coded in c#.

Technology used in this application 
*The software used to build this application is Visual Studio 2022. 
*Net frameworks *Plugins

Description of the user interface 
*This program is a console app – command line application.
 Websites used to build this application 
 https://www.siyavula.com/read/maths/grade-10/finance-and-growth/09-finance-and-growth-03 
 https://stackoverflow.com/questions/33698676/classes-and-base-class-inheritance-in-c-sharp 
 https://www.guru99.com/c-sharp-arraylist.html 
 https://stackoverflow.com/questions/33698676/classes-and-base-class-inheritance-in-c-sharp 
 https://stackoverflow.com/questions/2963742/empty-constructor-or-no-constructor

Known bugs
 *There are currently no bugs in this program *Program runs efficiently

Project status
 *This program has been completed with more features will added since the previous program presented. The new features of this program enable the user to choose whether they are purchasing a vehicle. The software is to be now able to calculate the monthly cost for buying a car. 
 *Project has been completed in a console app format 
 *This program is planned to have a GUI environment, where users will be able to interact with it in a graphical environment.
 *It is planned to be built using either Windows Presentation Foundation (WPF).

License 
*MIT license

Developer Information *Name: Revali Reddy (ST10084347) *Tertiary education: - Varsity College: 2nd year Bachelor of Computer Science in applications development [2022] - GitHub profile: revalireddy *Email: st10084347@gmail.com

FAQ 
Q: What is range of months that chosen for purchasing a home? 
*The user is only allowed to choose between 260 or 360 
Q: How many expenses can be entered under other expenses? 
*The user is only allowed to enter one other general expense 
Q: Will the value entered for the interest rate be converted to a percentage? 
*The interest rate can be entered a decimal and will be converted to a percentage 
Q: Is the vehicle period fixed and how long is it? 
*Yes, assume that all vehicles will be reimbursed over a five-year period. 
Q: Can you refer to your previous budgets? 
*No, Users may not be able to see previous budget reports as there is no database used for this program 

GitHub Links Repository link: 
https://github.com/revalireddy/Prog6211-ST10084347-Poe-Task1.git 
Kanban link: https://github.com/users/revalireddy/projects/1

