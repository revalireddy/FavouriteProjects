﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace BudgetApp4
{
    class Program
    {
        //declare the delegate
        //Microdoft[online]|How to declare, instantiate, and use a Delegate (C# Programming Guide)|Available:https://docs.microsoft.com/en-us/dotnet/csharp/programming-guide/delegates/how-to-declare-instantiate-and-use-a-delegate
        public delegate void totalExceedingDelegate(double totalExpenses, double AccomadationCost, double vehicleCosts, double income);
       

        //variable to store the monthly income of the user
        private static double grossIncome;
  
        //variables to store the various expenses entered by the user
        private static double AccomadationCost;
        private static double totalExpenses;
        private static double vehicleCosts;

        //generic collection - List - will store the expenses entered by the user 
        private static List<double> expenses = new List<double>();

        //variables to store the information entered by the user for the vehicle the are budgeting for 
        private static String makeAndModel;
        private static double purchasePrice;
        private static double deposit;
        private static double interestRate;
        private static double insurancePremium;

        static void Main(string[] args)
        {
            //delegate
            totalExceedingDelegate ted = new totalExceedingDelegate(exceedingGross);


            /*                    -- introduction --
             * splashscreen
             * uses thread to count
             * houseKeeping
             */
            Console.BackgroundColor = ConsoleColor.Black;
            Console.ForegroundColor = ConsoleColor.Red;
            string s = "****************** BUDGET PLAN APP *****************\n\n";
            Console.SetCursorPosition((Console.WindowWidth - s.Length) / 2, Console.CursorTop);
            Console.WriteLine(s);
            //Dayan[online](20 February 2014)|How do I center text in a console application? [duplicate]|Available:https://stackoverflow.com/questions/21917203/how-do-i-center-text-in-a-console-application

            Console.WriteLine("Loading...");

            for (int i = 5; i > 0; i--)
            {
             //Anonymous[online](24 January 2019)|How to create Threads in C#|Available :https://www.geeksforgeeks.org/how-to-create-threads-in-c-sharp/
                Console.Write(i + "  ");
                Thread.Sleep(1000);

            }
             Console.WriteLine("\n");
            //colour scheme used to differentiate the different expenses entered by the user , to make it more vissibly appealing
            Console.BackgroundColor = ConsoleColor.Black;
            Console.ForegroundColor = ConsoleColor.Green;

            //pulls methods into main method to execute

            userBasicExpenses();

            userGeneralExpenses();

            Console.BackgroundColor = ConsoleColor.Black;
            Console.ForegroundColor = ConsoleColor.Blue;


            AccomadationOptions();

            Console.BackgroundColor = ConsoleColor.Black;
            Console.ForegroundColor = ConsoleColor.DarkMagenta;

            purchaseVehicle();


            Console.BackgroundColor = ConsoleColor.Black;
            Console.ForegroundColor = ConsoleColor.Red;

            ted(totalExpenses, AccomadationCost, vehicleCosts, grossIncome);

            Console.BackgroundColor = ConsoleColor.Black;
            Console.ForegroundColor = ConsoleColor.White;

            printAllExpenses();

            moneyAvailable();

            Console.ReadKey();
        }
        static void userBasicExpenses()  //method to retrieve user input about income and their tax
        {
            try
            {
                Console.Write("************************************\n\n");
                Console.Write("Enter your gross monthly income : R ");
                grossIncome = Convert.ToDouble(Console.ReadLine());

                Console.Write("Enter your estimated monthly tax: R ");
                expenses.Add(Convert.ToDouble(Console.ReadLine()));
                Console.WriteLine("**********************************\n\n");
            }
            catch (Exception ex)
            {

                // handle exception here
                Console.WriteLine("Invalid entry");
                userBasicExpenses();
            }

        }
        static void userGeneralExpenses() //method to retrieve user input  about general expenses
        {
            //Anonymous[online]|Java ArrayList |Available+:https://www.w3schools.com/java/java_arraylist.asp
            Console.Write("Enter the estimated monthly cost for:\n");
            try
            {
                Console.Write("Groceries                      : R ");
                expenses.Add(Convert.ToDouble(Console.ReadLine()));

                Console.Write("Water and lights               : R ");
                expenses.Add(Convert.ToDouble(Console.ReadLine()));

                Console.Write("Travel costs(including petrol) : R ");
                expenses.Add(Convert.ToDouble(Console.ReadLine()));

                Console.Write("Cell phone and telephone       : R ");
                expenses.Add(Convert.ToDouble(Console.ReadLine()));

                Console.Write("Other expenses                 : R ");
                expenses.Add(Convert.ToDouble(Console.ReadLine()));

                Console.WriteLine("**********************************\n\n");
            }
            catch (Exception ex)
            {
                // handle exception here
                Console.WriteLine("Invalid entry");
                userGeneralExpenses();
            }
        }
        //method to allow user to choose between renting and buying a house
        static void AccomadationOptions()
        {
            //display - provide the user with the ability to choose between the 2 options
            Console.WriteLine("Accomdation:");
            Console.WriteLine("Will you be renting accomadation or buying a property?");
            Console.WriteLine("Enter '1' for renting ");
            Console.WriteLine("or ");
            Console.WriteLine("'2' for buying ");
            int option = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("");

            if (option == 1)
            {
                rentalMethod();
               
               
            }
            else if (option == 2)
            {
                purchaseHouseMethod();
            }
            else
            {
                Console.WriteLine("Invalid selection - please try again.");
                AccomadationOptions();
            }
            Console.WriteLine("\nAccomodation cost : R " + AccomadationCost);
            Console.WriteLine("**********************************\n\n");
        }
        //method to pull methods regarding entered values from the user
        static void rentalMethod()
        {
            //
            //VidyahA[blog]|Object Oriented Programming Using C# .NET|Available:https://www.c-sharpcorner.com/UploadFile/84c85b/object-oriented-programming-using-C-Sharp-net/
            Rent collect = new Rent();

            collect.setExpenses(expenses);

            totalExpenses = collect.getAllExpenses();
            //the following calculation will provide the user with an amount of how much money is left over
            AccomadationCost = collect.monthlyRepayments();
            expenses.Add(AccomadationCost);

            

        }
        //method to pull methods regarding entered values from the user
        static void purchaseHouseMethod()
        {
            //VidyahA[blog]|Object Oriented Programming Using C# .NET|Available:https://www.c-sharpcorner.com/UploadFile/84c85b/object-oriented-programming-using-C-Sharp-net/
            HomeLoan collect = new HomeLoan();

            collect.setExpenses(expenses);

            totalExpenses = collect.getAllExpenses();

            AccomadationCost = collect.monthlyRepayments();
            //the accomadationg cost is added to the generic collection
            expenses.Add(AccomadationCost);
            //checks and shows the user if they are eligible for a loan or not
            collect.loanAccepted(grossIncome);

           
        }

        static void purchaseVehicle()
        {
            //display - provide the user with the ability to choose between the 2 options
           
                
                Console.WriteLine("Vehicle:");
                Console.WriteLine("Will you be buying a car?");
                Console.WriteLine("Enter '1' for Yes ");
                Console.WriteLine("or ");
                Console.WriteLine("'2' for No ");
           
           

            int option = Convert.ToInt32(Console.ReadLine());

            if (option == 1)

            {
                //Chris Mantle(23 June 2014)[blog]|Pulling objects from a collection that satisfies a condition|Available:https://stackoverflow.com/questions/24356861/pulling-objects-from-a-collection-that-satisfies-a-condition
                //pull method toallow user to enter the necessary details about the car they would like to buy
                userVehicleinput();

                //car class is pull - uses constructor 
                Car boughtCar = new Car(makeAndModel, purchasePrice, deposit, interestRate, insurancePremium);

                vehicleCosts = boughtCar.monthlyRepayments();
                //the vehicle costs are added tothe generic collection
                expenses.Add(vehicleCosts);

                Console.WriteLine("\nVehicle cost      : R " + vehicleCosts);

            }
            else if (option == 2)
            {
               
            }
            Console.WriteLine("**********************************\n\n");

        }
        static void userVehicleinput()//the user is given a display to enter the details for the c=car the want to purchase
        {
            //exception handling
            //Microsoft(25 January 2022)[online]|Exception Handling (C# Programming Guide)|Available:https://docs.microsoft.com/en-us/dotnet/csharp/fundamentals/exceptions/exception-handling
            try
            {
                // put the code here that may raise exceptions
                Console.Write("Enter the make and model of the vehicle              : ");
                makeAndModel = Console.ReadLine();

                Console.Write("Enter the purchase price of the vehicle              :R");
                purchasePrice = Convert.ToDouble(Console.ReadLine());

                Console.Write("Enter the deposit for the vehicle                    :R");
                deposit = Convert.ToDouble(Console.ReadLine());

                Console.Write("Enter the interest rate for the vehicle              :");
                interestRate = Convert.ToDouble(Console.ReadLine());

                Console.Write("Enter the monthly insurance premium for the vehicle  :R");
                insurancePremium = Convert.ToDouble(Console.ReadLine());
            }
            catch (Exception ex)
            {
                // handle exception here
                Console.WriteLine("Invalid entry");
                userVehicleinput();
            }

        }


        static void printAllExpenses() //method to display all expenses that have been entered  by the user
        {
            
            //thread - to set a time stamp
            //A thread has been used to display the expenses , one by one, in timed manner 
            Thread.Sleep(500);
            Console.WriteLine("List of expenses in descending order are as follows :\n");

            int count = 1;
            //Barry(12 october 2012)[Blog]|Ordering a DataTable in Descending Order using Multiple Columns C#|Available: https://stackoverflow.com/questions/52780773/ordering-a-datatable-in-descending-order-using-multiple-columns-c-sharp
            //loop will display all expenses in descending order
            foreach (double x in expenses.OrderByDescending(x => x))

            {
                Console.WriteLine("R" + x.ToString() + "\n");
                count++;
            }

           

        }
        static void moneyAvailable() //method calculates the money that is left over
        {
            //calulation subtracts all the expenses from the income and then displays the final amount
           
            double availableAmount = grossIncome - (totalExpenses + AccomadationCost + vehicleCosts);
            Console.WriteLine("Your available monthly money balance: R " + Math.Round((Double)availableAmount, 2));

        }

        static void exceedingGross(double totalExpenses, double AccomadationCost, double vehicleCosts, double income) //parameterised method
        {
            //w3School[online]|C# Method Parameters|Available:https://www.w3schools.com/cs/cs_method_parameters.php
            //variable to store value after all expenses are added
            double FinalExpenses;
            FinalExpenses = totalExpenses + AccomadationCost + vehicleCosts;

            /*if else statement - the total income is compared to 3/4 of the users gross monthly income
             * if all the expenses added is greater than 3/4 of the income the program will alert the user - displayed in yellow
             * else the program will display a friendly message in green 
             */

            if (FinalExpenses > (income * 3 / 4))
            {
                Console.BackgroundColor = ConsoleColor.DarkYellow;
                Console.ForegroundColor = ConsoleColor.Black;
                Console.WriteLine("\nALERT : Total expenses are greater than 75 percent of the gross income\n");
                Console.BackgroundColor = ConsoleColor.Black;
                Console.ForegroundColor = ConsoleColor.White;

            }
            else if (FinalExpenses < (income * 3 / 4))
            {
                Console.BackgroundColor = ConsoleColor.Green;
                Console.ForegroundColor = ConsoleColor.White;
                Console.WriteLine("Total expenses are less than 75 percent of the gross income");
                Console.BackgroundColor = ConsoleColor.Black;
                Console.ForegroundColor = ConsoleColor.White;

            }

         
            Console.WriteLine("**********************************\n\n");
        }
    }
}

     
    


        
    


