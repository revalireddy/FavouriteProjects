﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BudgetApp4
{
    //Car - child class  , is derived from the expenses - parent class
    class Car : Expenses
    {
        //variables to store information entered by user about the car they will purchase
        private string makeAndModel;
        private double deposit;
        private double purchasePrice;
        private double interestRate;
        private double insurancePremium;

        //constuctor 
        //G Mike(3 November 2013)[blog]|C# - Making all derived classes call the base class constructor |Available :https://stackoverflow.com/questions/4296888/c-sharp-making-all-derived-classes-call-the-base-class-constructor
        public Car (string makeAndModel, double purchasePrice, double deposit, double interestRate, double insurancePremium)
        {
            this.makeAndModel = makeAndModel;
            this.purchasePrice = purchasePrice;
            this.deposit = deposit;
            this.interestRate = interestRate;
            this.insurancePremium = insurancePremium;
        }

        //method overriden from the expenses class

        public override double monthlyRepayments()
        {

            //method calculates the amount a user will pay every mont if they were to purchase a car 
            //Mike Gold(09 April 2008[online]|Mortgage Calculator in C# and .NET |Available :https://www.c-sharpcorner.com/
           
                double cost = 0;
                double monthlyCost = 0;

                double principleAmount = purchasePrice - deposit;
                interestRate = interestRate / 100;

                cost = principleAmount * (1 + (interestRate * 5));

                monthlyCost = cost / 60;
                monthlyCost += insurancePremium;
                return Math.Round((Double)monthlyCost, 2);
          

        }

    }
}
