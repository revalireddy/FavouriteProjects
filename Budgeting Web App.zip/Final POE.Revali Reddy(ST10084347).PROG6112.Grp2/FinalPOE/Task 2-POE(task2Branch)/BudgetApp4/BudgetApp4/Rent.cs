﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BudgetApp4
{
    //rent - child class  , is derived from the expenses - parent class
    class Rent : Expenses
    {
        //variable to store rent entered by the user
        private double rentAmount;
        //Ram (3 June 2010) [blog]|Empty constructor or no constructor |Available:https://stackoverflow.com/questions/2963742/empty-constructor-or-no-constructor
        public Rent()
        {

        }


        //method retrieves monthly rent from user - overrides the monthlyRepayments method in expenses class
        public override double monthlyRepayments()
        {
            Console.Write("Enter the monthly rental amount :");
            rentAmount = Convert.ToDouble(Console.ReadLine());
            return rentAmount;
        }
    }
}
