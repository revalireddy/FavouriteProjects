﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BudgetApp4
{
    /*                 --abstract class--
    * Restrictive class that cannot be used to generate objects
    * Must be inherited from another class to be accessed.
    */
    abstract class Expenses
    {
        //array to store expenses
        private List<double > expenses = new List<double>();
        private double totalExpenses = 0;

        //population method
        public void setExpenses(List<double> userExpenses)
        {
            expenses = userExpenses;
        }

        //method calculates and adds all the expenses entered by the user
        public double getAllExpenses()
        {
            //Anonymous[online]|Return Statement |Available :https://riptutorial.com/csharp/learn/100011/return-statement
            totalExpenses = expenses.Sum();

            return totalExpenses;
        }

        public abstract double monthlyRepayments();

    }
}

