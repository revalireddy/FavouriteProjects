﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace BudgetAppGUI
{
    //This class controls how the user will interact with interface
    public partial class Rent : Window
    {
        //Object hc has been created to call the variables created in the HomeLoan class , making it accessible in this class
        HomeCalc hc = new HomeCalc();
        public Rent()
        {
            //Creates an instance of your Application object, calls its InitializeComponent method and then its Run method
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)//enter button
        {
            //A display message to confirm that the values entered by users ahave been saved
            MessageBox.Show("Information saved!");

            //The boolean value will help the program respond to abnormal input or conditions and prevent it from crashing 
            Boolean goodEntry = true;


            /* -- EXCEPTION HANDELING--
             Allows the block of code to be tested for errors while it is being executed. 
             The catch statement allows the block of code to be executed, if an error occurs in the try block.
            */
            try
            {
                //Variables from class is called and given a value that will be utilized in the homeloan class's calculations.
                hc.rentalAmount = Convert.ToDouble(rentTB.Text);
            }
            catch (Exception)
            {
                //The boolean is set to false, preventing the following page from being displayed.
                goodEntry = false;


                //A message to display that user has not completed all details
                MessageBox.Show("Error!\nPlease complete all required details");
                //Clears the textbox
                rentTB.Clear();

                /* --colours--
                 * -when the error appears , the text blocks will be highlighted in red
                 * -this will make the GUI application more interactive
                 * -as it clearly indicates which the error and the textblocks left empty
                 * --and need completion
                 */

                
                rentTB.Background = Brushes.Yellow;
                rentTB.Foreground = Brushes.Black;
               
                
            }

            //If statement for error handling
            if (goodEntry == true)
            {
                //Object of the next window
                OptionsPage op = new OptionsPage();
                //Displays the next window
                op.Show();
                //Closes this window
                this.Close();
            }
        }

        private void Button_Click_1(object sender, RoutedEventArgs e) //back button
        {

            //object op created to call the next window
            OptionsPage op = new OptionsPage();
            //Shows the next window
            op.Show();
            //Closes this window
            this.Close();
        }
    }
}
