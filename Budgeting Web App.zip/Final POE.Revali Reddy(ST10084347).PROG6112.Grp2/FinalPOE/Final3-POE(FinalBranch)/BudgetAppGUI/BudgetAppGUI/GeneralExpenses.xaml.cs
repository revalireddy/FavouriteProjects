﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace BudgetAppGUI
{
    //This class controls how the user will interact with interface
    public partial class GeneralExpenses : Window
    {
        //Object created to call homeCalc class
        HomeCalc hc = new HomeCalc();

      
        public GeneralExpenses()
        {
            //Creates an instance of your Application object, calls its InitializeComponent method and then its Run method
            InitializeComponent();
        }

       
        public void Button_Click(object sender, RoutedEventArgs e)//Enter buttonb method
        {


            //A display message to confirm that the values entered by users ahave been saved
            MessageBox.Show("Information saved!");

            
            /* -- EXCEPTION HANDELING--
             Allows the block of code to be tested for errors while it is being executed. 
             The catch statement allows the block of code to be executed, if an error occurs in the try block.
            */
            try
            {
                //Variables from the Variables class is called and given a value that will be utilized in the homeloan class's calculations
                hc.Income = Convert.ToDouble(incomeTb.Text);
            }
            catch (Exception)
            {
                //A message to display that user has not completed all details
                MessageBox.Show("Error!\nPlease complete all required details!");

                /* --colours--
               * -when the error appears , the text blocks will be highlighted in red
               * -this will make the GUI application more interactive
               * -as it clearly indicates which the error and the textblocks left empty
               * --and need completion
               */

                incomeTb.Clear();
                incomeTb.Background = Brushes.Yellow;
                incomeTb.Foreground = Brushes.Black;
            }

            try
            {
                hc.ExpensesNumb.Add(Convert.ToDouble(taxTB.Text));
            }
            catch (Exception)
            {
                MessageBox.Show("Error!\nPlease complete all required details!");
                taxTB.Clear();
                taxTB.Background = Brushes.Yellow;
                taxTB.Foreground = Brushes.Black;
            }

            try
            {
                // MirosoftDocs|List<T>.Add(T) Method|Available:https://docs.microsoft.com/en-us/dotnet/api/system.collections.generic.list-1.add?view=net-6.0
                hc.ExpensesNumb.Add(Convert.ToDouble(groceriesTB.Text));
            }
            catch (Exception)
            {
                MessageBox.Show("Error!\nPlease complete all required details!");
                groceriesTB.Clear();
                groceriesTB.Background = Brushes.Yellow;
                groceriesTB.Foreground = Brushes.Black;
            }

            try
            {
                hc.ExpensesNumb.Add(Convert.ToDouble(waterTB.Text));
            }
            catch (Exception)
            {
                MessageBox.Show("Error!\nPlease complete all required details!");
                waterTB.Clear();
                waterTB.Background = Brushes.Yellow;
                waterTB.Foreground = Brushes.Black;
            }

            try
            {
                hc.ExpensesNumb.Add(Convert.ToDouble(travelTB.Text));
            }
            catch (Exception)
            {
                MessageBox.Show("Error!\nPlease complete all required details!");
                travelTB.Clear();
                travelTB.Background = Brushes.Yellow;
                travelTB.Foreground = Brushes.Black;
            }

            try
            {
                hc.ExpensesNumb.Add(Convert.ToDouble(cellTB.Text));
            }
            catch (Exception)
            {
                MessageBox.Show("Error!\nPlease complete all required details!");
                cellTB.Clear();
                cellTB.Background = Brushes.Yellow;
                cellTB.Foreground = Brushes.Black;
            }

            try
            {
                hc.ExpensesNumb.Add(double.Parse(otherTB.Text));
            }
            catch (Exception)
            {
                MessageBox.Show("Error!\nPlease complete all required details!");
                otherTB.Clear();
                otherTB.Background = Brushes.Yellow;
                otherTB.Foreground = Brushes.Black;
            }
        }

       
        private void Button_Click_1(object sender, RoutedEventArgs e)//button to purhcase house
        {
           
            HouseBudget hb = new HouseBudget();
             hb.Show(); 
            this.Close();
        }

  
        private void Button_Click_2(object sender, RoutedEventArgs e) //button for rent
        {
 
            Rent rh = new Rent();
             rh.Show();
            this.Close();
        }
    }
    }
