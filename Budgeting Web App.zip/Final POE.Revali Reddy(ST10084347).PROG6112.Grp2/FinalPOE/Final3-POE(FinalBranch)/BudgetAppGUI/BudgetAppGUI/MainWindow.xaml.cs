﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace BudgetAppGUI
{
    //This class controls how the user will interact with interface
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void home_Selected(object sender, RoutedEventArgs e) //if the home icon is selected , it shall take the user to the next page
        {
            //Object ge has been created to call the next class
            GeneralExpenses ge = new GeneralExpenses();
            //The next page will be displayed
            ge.Show();
            //The current page will be closed
            this.Close();

        }

        private void exit_Selected(object sender, RoutedEventArgs e)//when the exit icon is clicked by the user the application shall close 
        {
             
            this.Close();

        }

        private void BG_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            //adds convenience of not needing to check the mouse button states left-right, up-down of the original mouse events in the event data
        }
    }
}
