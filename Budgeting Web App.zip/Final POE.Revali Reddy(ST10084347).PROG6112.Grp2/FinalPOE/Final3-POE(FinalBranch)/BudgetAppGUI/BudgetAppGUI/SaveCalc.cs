﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BudgetAppGUI
{
    //Programiz[online]|C# Inheritance|Available:https://www.programiz.com/csharp-programming/inheritance
    public class SaveCalc : VariableClass
    {
            public double save() //method to calculate the monthly payment towards savings
            {
                monthlyPay = SavingsAmount / Months / (interestRate / 100);

                return monthlyPay; //returns the value that the user will have to  pay towards savings
            }
        
    }
}
