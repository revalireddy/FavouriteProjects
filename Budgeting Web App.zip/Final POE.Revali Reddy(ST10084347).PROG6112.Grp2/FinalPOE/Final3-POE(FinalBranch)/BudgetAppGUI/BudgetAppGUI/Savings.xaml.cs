﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace BudgetAppGUI
{

    //This class controls how the user will interact with interface
    public partial class Savings : Window
    {

        //Object save has been created to call the variables created in the carLoan class , making it accessible in this class
        SaveCalc save = new SaveCalc();

     
        public Savings()
        {
            //Creates an instance of your Application object, calls its InitializeComponent method and then its Run method
            InitializeComponent();
        }

        private void savingsEnterBtn_Click(object sender, RoutedEventArgs e)
        {
            //The boolean value will help the program respond to abnormal input or conditions and prevent it from crashing 
            //W3Schools[online] |C# Booleans|Available:https://www.w3schools.com/cs/cs_booleans.php
            Boolean goodentry = true;

            //A display message to confirm that the values entered by users ahave been saved
            MessageBox.Show("Information saved!");



            /* -- EXCEPTION HANDELING--
             Allows the block of code to be tested for errors while it is being executed. 
             The catch statement allows the block of code to be executed, if an error occurs in the try block.
            */


            //Variables from the savingCalculations class is called and given a value that will be utilized in the carloan class's calculations.
            save.Reason = reasonTB.Text;

            // MicrosoftDocs(02 April 2022)[online]|try-catch (C# Reference) |Available:https://docs.microsoft.com/en-us/dotnet/csharp/language-reference/keywords/try-catch
            try
            {
                //Variables from the savingCalculations class is called and given a value that will be utilized in the carloan class's calculations.
                save.SavingsAmount = Convert.ToDouble(ammountTB.Text);
            }
            catch (Exception)
            {
                //The boolean is set to false, preventing the following page from being displayed.
                goodentry = false;

                //A message to display that user has not completed all details
                MessageBox.Show("Error!\nPlease complete all required details");


                /* --colours--
                 * -when the error appears , the text blocks will be highlighted in red
                 * -this will make the GUI application more interactive
                 * -as it clearly indicates which the error and the textblocks left empty
                 * --and need completion
                 */

               

                reasonTB.Background = Brushes.Yellow;
              
                reasonTB.Foreground = Brushes.Black;
               
                reasonTB.Clear();
            }

            try
            {
                //EDUCUBA[online]|How to Convert String to Double in C#?|Available:https://www.educba.com/convert-string-to-double-in-c-sharp/
                save.InterestRate = Convert.ToDouble(savingsInterestTB.Text);
            }
            catch (Exception)
            {
                goodentry = false;
                MessageBox.Show("Error!\nPlease complete all required details");
                savingsInterestTB.Background = Brushes.Yellow;
                savingsInterestTB.Foreground = Brushes.Black;
                savingsInterestTB.Clear();
            }

            try
            {
                save.Months = Convert.ToDouble(numbOfMonthsTb.Text);
            }
            catch (Exception)
            {
                goodentry = false;
                MessageBox.Show("Error!\nPlease complete all required details");
                numbOfMonthsTb.Background = Brushes.Yellow;
                numbOfMonthsTb.Foreground = Brushes.Black;
                numbOfMonthsTb.Clear();
            }

            /*
            * If the user click enter and all values are valid they will be taken to the next back
            * where they will be presented with other options of budgeting
            */
            if (goodentry == true)
            {
                
                Expenses ex = new Expenses();
                ex.Show();
                this.Close();
            }

        }
        private void Button_Click_2(object sender, RoutedEventArgs e) //button to purchased a car
        {
            Boolean goodentry = true;

           
            if (goodentry == true)
            {
                CarBudget cb = new CarBudget();
                cb.Show();
                this.Close();
            }
        }

    }
    }