﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace BudgetAppGUI
{
    //This class controls how the user will interact with interface
    public partial class Expenses : Window

    { 
     //Object hc has been created to call the variables created in the HomeLoan class , making it accessible in this class
     HomeCalc hc = new HomeCalc();

     //Object cc has been created to call the variables created in the HomeLoan class , making it accessible in this class
     CarCalc cc = new CarCalc();


     //Object sc has been created to call the variables created in the HomeLoan class , making it accessible in this class
     SaveCalc sc = new SaveCalc();

        //Delegates allows methods to be passed as parameters
        //tutorialsteacher[online]|C# - Delegates|Available:https://www.tutorialspoint.com/csharp/csharp_delegates.htm
        public delegate string expenseExceedingDelegate(string exceedNotification);

    //Variables for house
    string house = null;
    double homeRepayment = 0;

    //variables for car
    string car = null;
    double carRepayment = 0;

    //variables for savings
    string savings = null;
    double savingsRepayment = 0;

    //variable to store the final balance
    double totalBalance;


    public Expenses()
    {
        //Creates an instance of your Application object, calls its InitializeComponent method and then its Run method
        InitializeComponent();

             //--IF STATEMENTS FOR RENT AND HOUSE--

        //If-else statement to allow user to choose between buying a house or renting 
        if (hc.rentalAmount > 0) //if the input is greater than zero, the message will below will be displayed to the user
        {
               // tutorialspoint[online]| Difference between % d and % i format specifier in C |Available:https://www.tutorialspoint.com/chash-currency-c-format-specifier
                house = "\n\nRent repayment : " + hc.rentalAmount.ToString("C");
            //the homeRepayment value will then store a value
            homeRepayment = hc.rentalDeduction();
        }
        else if (hc.monthlyRepayment() > 0) //if the input is greater than zero , the message below will be displayed
        {

            house = "\n\nHome loan repayment: " + hc.monthlyRepayment().ToString("C");

            homeRepayment = hc.houseDeduction();
        }

             //--IF STATMENTS FOR CAR--

        if (cc.monthlyCarRepayment() > 0)
        {
            //If the input is greater than zero, the message will below will be displayed to the user
            car = "\n\nCar loan repayment " + cc.makeModel + " will be : " + cc.monthlyCarRepayment().ToString("C");
            //the carRepayment value will then store a value
            carRepayment = cc.monthlyCarRepayment();
        }


              //--IF STATEMENTS FOR SAVINGS--
        //If the input is greater than zero, the message will below will be displayed to the user
        if (sc.save() > 0)
        {
            //If the input is greater than zero, the message will below will be displayed to the user
            savings = "\n\nMonthly savings contribution " + sc.Reason + " will be :" + sc.save().ToString("C");
            //the savingsRepayment value will then store a value
            savingsRepayment = sc.save();
        }

              //--TOTAL BALANCE--
        //Calculation to provide the user with their total balance
        totalBalance = homeRepayment - carRepayment - savingsRepayment;

             //--DISPLAY
        //Displays the following in a textblock
        expensesTextBlock.Text = "\t\tYOUR-MONTHLY-SUMMARY! : "
                                 + "\n\nTotal balance : " + totalBalance.ToString("C")
                                 + "\n\nMonthly expenditure : " + hc.ExpensesNumb.Sum().ToString("C")
                                 + house
                                 + car
                                 + savings;
    }

    static void delegateMethod()
    {
            //a reference type variable that holds the reference to a method. 
            expenseExceedingDelegate eed = (exceedNotificaton) => { return exceedNotificaton; };
        //a string message is returned
        MessageBox.Show(eed("Warning!!!\nYour total expenses exceed 75% of your expenses,\nincluding home loan repayments!"));
    }


    private void Button_Click(object sender, RoutedEventArgs e) //when the button is clicked
    {
        //the total balace calculated above is compared to the the calculation in the if statement
        //75% of the income iscompared to the totalbalance
        if (totalBalance <= 0.75 * hc.Income)
        { delegateMethod(); }
        //Closes the window
        this.Close();
    }
   
}

   }

