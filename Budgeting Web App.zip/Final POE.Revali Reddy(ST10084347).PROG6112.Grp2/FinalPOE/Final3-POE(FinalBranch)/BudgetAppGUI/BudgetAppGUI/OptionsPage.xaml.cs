﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace BudgetAppGUI
{
    //This class controls how the user will interact with interface
    public partial class OptionsPage : Window
    {
        public OptionsPage()
        {
            //Creates an instance of your Application object, calls its InitializeComponent method and then its Run method
            InitializeComponent();
   
            HomeCalc hc = new HomeCalc();

         /*
         * The program will display a summary of the variables
         * It will use this variable which is set to null
         */
            string userChoices = null;

            //If-else statement for determining which statements should be included in the userChoices string
            if (hc.rentalAmount > 0)
            {
                //If the rent is larger than 0, it sends a message to the variable and will output the message below
                userChoices = "Monthly Rent Repayment : " + hc.rentalAmount.ToString("C")
                                + "\n\nBalance : " + hc.rentalDeduction().ToString("C");
            }
            else if (hc.monthlyRepayment() > 0)
            {
                //If the home loan repayment is more than 0, the message below will be outputed to the user
                userChoices = "Monthly home loan repayment: " + hc.monthlyRepayment().ToString("C")
                                + "\n\nBalance : " + hc.houseDeduction().ToString("C");
             }

             //A message will be displayed in the text block.
            chooseCarTextBlock.Text = "Monthly income after housing deductions : " + hc.netIncome().ToString("C") + "\n\n" + userChoices;
             }

            private void buyCarBtn_Click(object sender, RoutedEventArgs e)
            {

             //Object cb has been created to call the class
             CarBudget cb = new CarBudget();
              //Shows the next window 
             cb.Show();
            //Closes the current window
            this.Close();

            }

            private void expensesBtn_Click(object sender, RoutedEventArgs e)//this button is if the user selects to view expenses
            {

             //Object ex has been created to call the next class
             Expenses ex = new Expenses();
              //Shows the next window 
             ex.Show();
             //Closes the current window
            this.Close();
             }

            private void Button_Click(object sender, RoutedEventArgs e)//this button is if the user selects to budget for savings
            {

             //Object sa has been created to call the next class
             Savings sa = new Savings();
            //Shows the next window 
             sa.Show();
            //Closes the current window
             this.Close();

             }
       }
    
}
