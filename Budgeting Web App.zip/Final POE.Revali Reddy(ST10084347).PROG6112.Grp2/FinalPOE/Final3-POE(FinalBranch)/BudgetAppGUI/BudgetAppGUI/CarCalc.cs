﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BudgetAppGUI
{
    internal class CarCalc : VariableClass
    {
        //Justin P[blog](15 January 2022)|What Is the Formula for a Monthly Loan Payment?|Available:https://www.thebalance.com/loan-payment-calculations

        public double monthlyCarRepayment()
        //Method calculates the monthly car repayment
        {
            //Calculation of the monthly payment for the car
            AmtAfterDeposit = ((purchasePrice - totalDeposit) + ((purchasePrice - totalDeposit) * interestRate / 100)) / 60;
            monthlyPay = AmtAfterDeposit + insurancePremium;
            return monthlyPay;
        }
    }
}
