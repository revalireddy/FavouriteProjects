﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace BudgetAppGUI
{

    //This class controls how the user will interact with interface
    public partial class CarBudget : Window
    {
        //Object cc has been created to call the variables created in the carLoan class , making it accessible in this class
        CarCalc cc = new CarCalc();
        public CarBudget()
        {
            //Creates an instance of your Application object, calls its InitializeComponent method and then its Run method
            InitializeComponent();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            //The boolean value will help the program respond to abnormal input or conditions and prevent it from crashing 
            Boolean goodEntry = true;

            //A display message to confirm that the values entered by users ahave been saved
            MessageBox.Show("Information saved!");

            /* -- EXCEPTION HANDELING--
             Allows the block of code to be tested for errors while it is being executed. 
             The catch statement allows the block of code to be executed, if an error occurs in the try block.
            */


            //teacherTutorials|Exception Handling in C#|Available:https://www.tutorialsteacher.com/csharp/csharp-exception-handling
            try
            {
                //Variables from the carloan class is called and given a value that will be utilized in the carloan class's calculations.
                cc.makeModel = makeTB.Text;
            }
            catch (Exception)
            {
                //The boolean is set to false, preventing the following page from being displayed.
                goodEntry = false;

                //A message to display that user has not completed all details
                MessageBox.Show("Error!\nPlease complete all required details");



                /* --colours--
                 * -when the error appears , the text blocks will be highlighted in red
                 * -this will make the GUI application more interactive
                 * -as it clearly indicates which the error and the textblocks left empty
                 * --and need completion
                 */


                makeTB.Foreground = Brushes.Black;
                makeTB.Background = Brushes.Yellow;
                makeTB.Clear();
            }

            //try-catch to check that user enters correct purchase price
            try
            {
                cc.PurchasePrice = Convert.ToDouble(carPurchaseTB.Text);
            }
            catch (Exception)
            {
                goodEntry = false;
                MessageBox.Show("Error!\nPlease complete all required details");
                carPurchaseTB.Foreground = Brushes.Black;
                carPurchaseTB.Background = Brushes.Yellow;
                carPurchaseTB.Clear();
            }
            //try-catch to check that user enters correct total deposit
            try
            {
                cc.TotalDeposit = Convert.ToDouble(carDepositTB.Text);
            }
            catch (Exception)
            {
                goodEntry = false;
                MessageBox.Show("Error!\nPlease complete all required details");
                carDepositTB.Foreground = Brushes.Black;
                carDepositTB.Background = Brushes.Yellow;
                carDepositTB.Clear();
            }
            //try-catch to check that user enters correct interest rate
            try
            {
                cc.InterestRate = Convert.ToDouble(carInterestTB.Text);
            }
            catch (Exception)
            {
                goodEntry = false;
                MessageBox.Show("Error!\nPlease complete all required details");
                carInterestTB.Foreground = Brushes.Black;
                carInterestTB.Background = Brushes.Yellow;
                carInterestTB.Clear();
            }
            //try-catch to check that user enters correct insurance premium
            try
            {
                cc.InsurancePremium = Convert.ToDouble(insuranceTB.Text);
            }
            catch (Exception)
            {
                goodEntry = false;
                MessageBox.Show("Error!\nPlease complete all required details");
                insuranceTB.Foreground = Brushes.Black;
                insuranceTB.Background = Brushes.Yellow;
                insuranceTB.Clear();
            }

            /*
             * If the user click enter and all values are valid they will be taken to the next back
             * where they will be presented with other options of budgeting
             */
            if (goodEntry == true)
            {
                //Object ex has been created to call the next class
                Expenses ex = new Expenses();
                //The next page will be displayed
                ex.Show();
                //The current page will be closed
                this.Close();
            }
        }
    }
}
