﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BudgetAppGUI
{
    public class HomeCalc : VariableClass
    {

        public double netIncome() //method to calculate the users income after they enter their expenses
        {
            /*
             * The list of t will add up all the expenses stored in the list and then substract it from the value stored in the  income 
             */
            return income - expensesNumb.Sum();
        }


        public double monthlyRepayment()//method to calculate the monthly home repayment
        {
            //variable stores the value after the interest rate is included 
            double FullAmount;

            //Nedbank[online]|calculators to see how much a home loan may cost you|Available:https://personal.nedbank.co.za/borrow/home-loans/repayments-and-bond-transfer-costs-calculator.html
            //AmtAfterDeposit variable will store the value after the deposit is substracted from the purchasePrice
            AmtAfterDeposit = purchasePrice - totalDeposit;


            //variable will store the the value before it ios divided by the months
            FullAmount = AmtAfterDeposit * (1 + (interestRate / 100) * (Months / 12));


            //variable stores the monthly amount that the user has to pay after it has been divided by the amount of months
            monthlyPay = FullAmount / Months;

            return monthlyPay;
        }
        public double rentalDeduction()///method to calculate the users income after they enter their rent expenses
        {
            // Value stored in the variable will be substract from the the balance amount
            return netIncome() - RentalAmount;
        }
        public double houseDeduction()  ///method to calculate the users income after they enter their house expenses
        {


            // Value stored in the variable will be substract from the the balance amount

            return netIncome() - monthlyRepayment();
        }


     
    }
}

