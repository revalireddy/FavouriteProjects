﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace BudgetAppGUI
{

    //This class controls how the user will interact with interface
    public partial class HouseBudget : Window
    {

        //Object hc has been created to call the variables created in the HomeLoan class , making it accessible in this class
        HomeCalc hc = new HomeCalc();
        public HouseBudget()
        {
            //Creates an instance of your Application object, calls its InitializeComponent method and then its Run method
            InitializeComponent();
        }
        private void Button_Click(object sender, RoutedEventArgs e)
        {

            //The boolean value will help the program respond to abnormal input or conditions and prevent it from crashing 
            Boolean goodEntry = true;

            //A display message to confirm that the values entered by users ahave been saved
            MessageBox.Show("Values have been entered!");

            /* -- EXCEPTION HANDELING--
             Allows the block of code to be tested for errors while it is being executed. 
             The catch statement allows the block of code to be executed, if an error occurs in the try block.
            */

            try
            {

                //Variables from the homeloan class is called and given a value that will be utilized in the homeloan class's calculations.
                hc.PurchasePrice = Convert.ToDouble(housePriceTB.Text);
            }
            catch (Exception)
            {
                //A message to display that user has not completed all details
                MessageBox.Show("Error!\nPlease complete all required details!");

                /* --colours--
                 * -when the error appears , the text blocks will be highlighted in red
                 * -this will make the GUI application more interactive
                 * -as it clearly indicates which the error and the textblocks left empty
                 * --and need completion
                 */

               
                housePriceTB.Foreground = Brushes.Black;
                housePriceTB.Background = Brushes.Yellow;
                housePriceTB.Clear();


                //The boolean value is set to false, which prevents the following page from being displayed.
                goodEntry = false;
            }

            try
            {
                hc.TotalDeposit = Convert.ToDouble(houseDepositTB.Text);
            }
            catch (Exception)
            {
                MessageBox.Show("Error!\nPlease complete all required details!");
                houseDepositTB.Foreground = Brushes.Black;
                houseDepositTB.Background = Brushes.Yellow;
                houseDepositTB.Clear();
                goodEntry = false;
            }

            try
            {
                hc.InterestRate = Convert.ToDouble(houseInterestTB.Text);
            }
            catch (Exception)
            {
                MessageBox.Show("Error!\nPlease complete all required details!");
                houseInterestTB.Foreground = Brushes.Black;
                houseInterestTB.Background = Brushes.Yellow;
                houseInterestTB.Clear();
                goodEntry = false;
            }

            try
            {
                hc.Months = Convert.ToDouble(houseMonthsTB.Text);
            }
            catch (Exception)
            {
                MessageBox.Show("Error!\nPlease complete all required details!");
                houseMonthsTB.Foreground = Brushes.Black;
                houseMonthsTB.Background = Brushes.Yellow;
                houseMonthsTB.Clear();
                goodEntry = false;
            }

            //If-else statement used to alert the user that their the monthly repayment is more than a third of the user's income
            if (hc.netIncome() / 3 <= hc.monthlyRepayment())
            {
                //A warning message is displayed to the user to show that they have failed the expectaqtion to aquire a homeLoan
                MessageBox.Show("Warning!!!\nYour expenses exceed your monthly gross income!");

                //Code to clear textboxes
                housePriceTB.Clear();
                houseDepositTB.Clear();
                houseInterestTB.Clear();
                houseMonthsTB.Clear();

                //Code to reset textboxes
                hc.PurchasePrice.Equals(0);
                hc.TotalDeposit.Equals(0);
                hc.InterestRate.Equals(0);
                hc.Months.Equals(0);
                //Keeps the page from closing
                goodEntry = false;
            }

            /*
             * If the user click enter and all values are valid they will be taken to the next back
             * where they will be presented with other options of budgeting
             */

            if (goodEntry == true)
            {
                //Object op has been created to call the next class
                OptionsPage op = new OptionsPage();
                //The next page will be displayed
                op.Show();
                //The current page will be closed
                this.Close();
            }
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            /*
             * This method refers to the back button
             * -it will go to the page that presents the user with other options of budgeting
             */


            //Object ge has been created to call the next class
            GeneralExpenses ge = new GeneralExpenses();
            //shows next window
            ge.Show();
            //keeps current window open
            this.Close();

        }
    }
}
