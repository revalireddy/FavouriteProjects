﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BudgetAppGUI
{
    //this class holds all the variables that willbe used throughout the program
    public abstract class VariableClass
    {
       
        public static List<double> expensesNumb = new List<double>(); //List of T to store all expenses entered by the user

       
        public static double income;//variable stores the gross monthly income of the user

                                      //-- GENERAL VARIABLES FOR CALCULATIONS--
        public static double purchasePrice;// variable stores the original amount of the car or house the user is budgeting for
        public static double totalDeposit; //variable stores the deposit that user pays for the car or house 
        public static double interestRate;//variable stores the proportion of the loan that is charged as interest to the user,
        public static double monthlyPay; //variable to store how much the user will repay every month after the calculation have been done
        public static double months;//varible store how many months the repayment is work on


                                      //--OTHER VAIRABLES--
        public static double AmtAfterDeposit;//Variable stores the amount after deposit has been deducted
        public static double RentalAmount;//Varible stores the amount for rental
        public static double insurancePremium;//Variable stores the users estimated insurance premium
        public static string reason;//Variable used in savings 
        public static string MakeModel;//Variable to store the Make and model of the car the user wants to budget for
        public static double savingsAmount;//Variable stores the desired amount the user needs to save towards

        //getter method returns its value
        //setter method sets or updates its value.

                                            //-- GENERAL VARIABLES FOR CALCULATIONS--
        public List<double> ExpensesNumb { get => expensesNumb; set => expensesNumb = value; }
        public double PurchasePrice { get => purchasePrice; set => purchasePrice = value; }
        public double TotalDeposit { get => totalDeposit; set => totalDeposit = value; }
        public double InterestRate { get => interestRate; set => interestRate = value; }
        public double MonthlyPay { get => monthlyPay; set => monthlyPay = value; }
        public double Months { get => months; set => months = value; }

                                                 //--OTHER VAIRABLES--
        public double amtAfterDeposit { get => AmtAfterDeposit; set => AmtAfterDeposit = value; }
        public double Income { get => income; set => income = value; }
        public double rentalAmount { get => RentalAmount; set => RentalAmount = value; }
        public double InsurancePremium { get => insurancePremium; set => insurancePremium = value; }
        public string Reason { get => reason; set => reason = value; }
        public double SavingsAmount { get => savingsAmount; set => savingsAmount = value; }
        public string makeModel { get => MakeModel; set => MakeModel = value; }
       
    }
}

