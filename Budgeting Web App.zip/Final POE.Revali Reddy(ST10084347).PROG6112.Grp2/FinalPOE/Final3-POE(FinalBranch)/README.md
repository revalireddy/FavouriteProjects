# FinalPOE
GUI
Contents of this file
*Introduction
*A guide to installation 
*About the program
*Requirements/Technical specifications
*Technology used in this application
*Description of the user interface
*Known bugs
*Project status
*Developer Information
*FAQ
The Budget Plan App
Version 5.0
Description
The Budget plan app has been created in the interest of assisting with personal budget planning. The aim of this app is to 
allow the user to track their expenses and make it simpler for the user to determine if they can make significant 
purchases like a home, as car or even save towards something.
A guide to installation 
*No installation is required for this program 
*Program runs from a GUI environment
*The project can be built by choosing to build from the build menu. The output pane will then display the output where 
compilation will take place.
*To run the code, begin with debugging. A GUI window shall then appear, displaying the introduction of the Budget Plan 
app with a Dashboard displayed.
*Or-. Open the BudgetAppGui folder/, Open the bin folder found in the BudgetAppGui folder/,Open the debug folder found 
in the bin folder/Open the BudgetAppGui – type: Application
*Visual studio is not required to run this app.
*Open the file containing the program, go to the bin folder, and then open debug, then run the application file
About of the program
*This program is coded using multiple classes which use inheritance. These include the rent, HomeCalc, carCalc and the 
saveCalc class which are the child classes, the expenses class which is the parent class.
*For each of these classes, a window is designed, to allow the user to visually interact
*The expense class (parent class) consists of all the variables which will be used in all the other child classes to get and 
use the values entered by the user to ultimately do calculations
*Child classes homeCalc, rent, carCalc and saveCalc consists of the methods that will calculate the monthly repayment 
from the values entered by the user.
*The expenses xaml.cs file untilmately displays the users’ expenses as well as alerts the user if they are exceeding 75% 
of their expenditure including the home repayment
*The expenses xaml.cs file also calculates the final balance which includes considering the housing expenses, general 
expenses and car expenses
*A delegate to notify the user when expenses exceed 75% of their income.
*A generic collection to store the expenses - list of T’s been used to store all expenses
*Exception handling – try-catch, has been used to ensure that the program does not crash
*Grids, buttons, textboxes, and labels have been used to design the interface
Requirements/Technical specifications
*This program is built to run on Windows 
*Program is coded in c#.
*Interface designed with xaml
Technology used in this application
*The software used to build this application is Visual Studio 2022.
*WPF.Net framework
*Plugins
Description of the user interface
*This program is an interactive graphical user interface
*Opens with a user-friendly dashboard.
*Simple ‘Exit’ button to end application
*WindowStyle to create a bar to exit at any point of the application.
Websites used to build this application
-Dayan[online] (20 February 2014)|How do I centre text in a console application? [duplicate]|Available:
https://stackoverflow.com/questions/21917203/how-do-i-center-text-in-a-console-application
-Anonymous[online] (24 January 2019) |How to create Threads in C#|Available:
https://www.geeksforgeeks.org/how-to-create-threads-in-c-sharp/
-Anonymous[online]|Java ArrayList |Available+:
https://www.w3schools.com/java/java_arraylist.asp
-VidyahA[blog]|Object Oriented Programming Using C# .NET Available:
https://www.c-sharpcorner.com/UploadFile/84c85b/object-oriented-programming-using-C-Sharp-net/
-Chris Mantle(23 June 2014)[blog]|Pulling objects from a collection that satisfies a 
condition|Available:https://stackoverflow.com/questions/24356861/pulling-objects-from-a-collection-that-satisfies-acondition
-Barry(12 october 2012)[Blog]|Ordering a DataTable in Descending Order using Multiple Columns C#|Available: 
https://stackoverflow.com/questions/52780773/ordering-a-datatable-in-descending-order-using-multiple-columns-csharp
-w3School[online]|C# Method Parameters|Available:
https://www.w3schools.com/cs/cs_method_parameters.php
-https://www.siyavula.com/read/maths/grade-10/finance-and-growth/09-finance-and-growth-03
-https://stackoverflow.com/questions/33698676/classes-and-base-class-inheritance-in-c-sharp
- https://www.guru99.com/c-sharp-arraylist.html
-https://stackoverflow.com/questions/33698676/classes-and-base-class-inheritance-in-c-sharp
-https://stackoverflow.com/questions/2963742/empty-constructor-or-no-constructor
-Maduri P [blog](8 May 2017)|Navigational panel|Available:https://www.c-sharpcorner.com/blogs/top-navigation-barusing-xaml
-Mahesh c[blog](18 July 2019)|ListView c#|Available:https://www.c-sharpcorner.com/UploadFile/mahesh/working-withlistview-in-C-Sharp/
-Avinash A(01 March 2019)|GridView|Available: https://www.c-sharpcorner.com/UploadFile/7eb164/gridview-control-inAsp-Net/
Known bugs
*There are currently no bugs in this program
*Program runs efficiently
Project status
*This program has been completed and is in a GUI environment, where users will be able to interact with it in a graphical 
environment.
*It is built in Windows Presentation Foundation (WPF).
License
*MIT license
Developer Information
*Name: Revali Reddy
*Student Number :(ST10084347)
*Tertiary education: 
 - Varsity College: 2nd year Bachelor of Computer Science in applications development [2022]
 - GitHub profile: revalireddy
*Email: st10084347@gmail.com
FAQ
Q: What is range of months that chosen for purchasing a home?
*The user is only allowed to choose between 260 or 360
Q: How many expenses can be entered under other expenses?
*The user is only allowed to enter one other general expense
Q: Will the value entered for the interest rate be converted to a percentage?
*The interest rate can be entered a decimal and will be converted to a percentage
Q: Is the vehicle period fixed and how long is it?
* Yes, assume that all vehicles will be reimbursed over a five-year period.
Q: Can you refer to your previous budgets? 
*No, Users may not be able to see previous budget reports as there is no database used for this program
Q: Can you skip answering the general expenses page
A: No, it required for calculations at a late stage
Q: At what amount am I restricted with being eligible for a home loan
A: The app calculates 1/3 of your income and is designed to notify you if you qualify or not 
Q: Does the app allow for decimal values, or will it crash if decimal values are entered
A: Yes, the app is built to allow users to enter any value, and if not valid, it will not crash
Q: Will my data be saved if I do not click the enter button by mistake
A: No, it will not be saved, hence the app stipulates that the enter button be clicked to save
Q: Can I go back to the dashboard 
A: No, it would be unnecessary, the dashboard simply provides a more friendly GUI, and provides the user with 2 options, 
should the user need to exit the application at any time, they can simply exit from the window bar at the top 
Q: Why can I not go back to the page to budget for expenses, after budgeting for savings
A: this application only allows the user to choose between either savings or budgeting for a car, as the application will 
need to come to an end at some point, however if savings is chosen first, an option to go to the car page is provided.
GitHub Links 
Repository link: https://github.com/revalireddy/Prog6211-ST10084347-Poe.git
Kanban link: https://github.com/users/revalireddy/projects/1
